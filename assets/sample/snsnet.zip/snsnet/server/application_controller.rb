class ApplicationController < ActionController::Base
  def fbredirect
    uri = URI.parse(request.url)
    @url = "snsnet://facebook?#{uri.query}"
  end


  def twredirect
    uri = URI.parse(request.url)
    @url = "snsnet://twitter?#{uri.query}"
  end
end