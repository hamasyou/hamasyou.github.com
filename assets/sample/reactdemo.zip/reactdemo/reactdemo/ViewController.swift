//
//  ViewController.swift
//  reactdemo
//
//  Created by 濱田 章吾 on 2014/11/21.
//  Copyright (c) 2014年 hamasyou. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        println("button1")
        
        var foo = "HOge"
        
        let filterFunc = { (enabled: AnyObject!) -> Bool in
            println("filter \(foo) \(enabled)")
            return enabled != nil
        }
        
        
        RACObserve(self.button, "enabled")
            .filter(filterFunc)
            .map({
                println("map \($0)")
                return ($0 as Bool) ? 1.0 : 0.3
            })
            .subscribeNext {
                println("called \($0)")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

