//
//  SecondViewController.swift
//  reactdemo
//
//  Created by 濱田 章吾 on 2014/11/21.
//  Copyright (c) 2014年 hamasyou. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var button2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        println("button2")
        RACObserve(self.button2, "enabled")
            .filter {
                println("filter2 \($0)")
                return $0 != nil
            }
            .map({
                println("map2 \($0)")
                return ($0 as Bool) ? 1.0 : 0.3
            })
            .subscribeNext {
                println("called2 \($0)")
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
