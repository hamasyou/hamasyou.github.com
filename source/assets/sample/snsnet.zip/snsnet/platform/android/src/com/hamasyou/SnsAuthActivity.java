package com.hamasyou;

import  android.app.Activity;
import  android.os.Bundle;
import  android.content.Intent;
import  android.util.Log;
import  android.net.Uri;

import org.appcelerator.titanium.TiApplication;
import org.appcelerator.titanium.TiRootActivity;
import org.appcelerator.titanium.proxy.ActivityProxy;
import org.appcelerator.kroll.KrollDict;

public class SnsAuthActivity extends Activity {

    private static final String TAG = "SnsAuthActivity";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "********* onCreate");

        Intent currentIntent = getIntent();
        Uri uri = currentIntent.getData();
        Log.d(TAG, "***** uri:" + uri);

        TiRootActivity app = (TiRootActivity) TiApplication.getAppRootOrCurrentActivity();
        ActivityProxy proxy = app.getActivityProxy();
        Log.d(TAG, "**** app:" + app);
        Log.d(TAG, "**** proxy:" + proxy);

        KrollDict event = new KrollDict();
        event.put("data", uri.toString());
        proxy.fireEvent("app:resume", event);

        finish();
    }

    @Override
    protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        Log.d(TAG, "********* onNewIntent");

        finish();
    }

}