

function onFacebookLogin(e) {
    var url = OAuth.addToURL('https://www.facebook.com/dialog/oauth', {
        client_id: Alloy.CFG.facebookConsumerKey,
        redirect_uri: 'http://example.com/fbredirect',
        scope: Alloy.CFG.facebookPermissions,
        auth_type: 'reauthenticate'
    });
    Ti.Platform.openURL(url);
}

function onTwitterLogin(e) {
    var oauth = new OAuth({
        consumerKey: Alloy.CFG.twitterConsumerKey,
        consumerSecret: Alloy.CFG.twitterConsumerSecret
    });
    oauth.get('https://api.twitter.com/oauth/request_token', {
        oauth_callback: 'http://example.com/twredirect'
    }, function(e) {
        Ti.Platform.openURL(String.format('%s?%s&force_login=false', 'https://api.twitter.com/oauth/authorize', this.responseText));
    });
}

$.index.open();
